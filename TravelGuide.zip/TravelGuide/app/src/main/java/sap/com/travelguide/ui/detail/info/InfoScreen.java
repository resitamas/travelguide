package sap.com.travelguide.ui.detail.info;

import sap.com.travelguide.ui.Screen;

/**
 * Created by I344065 on 2018. 01. 19..
 */

public interface InfoScreen extends Screen {
}
