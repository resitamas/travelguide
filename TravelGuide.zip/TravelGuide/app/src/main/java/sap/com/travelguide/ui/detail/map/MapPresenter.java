package sap.com.travelguide.ui.detail.map;

import sap.com.travelguide.ui.detail.DetailPresenter;

/**
 * Created by I344065 on 2018. 01. 19..
 */

public class MapPresenter extends DetailPresenter<MapScreen> {
}
