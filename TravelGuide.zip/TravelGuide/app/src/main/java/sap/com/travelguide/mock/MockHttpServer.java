package sap.com.travelguide.mock;

import okhttp3.Request;
import okhttp3.Response;

/**
 * Created by I344065 on 2018. 01. 18..
 */

public class MockHttpServer {

   /* public static Response call(Request request) {
        MockInterceptor mockInterceptor = new MockInterceptor();
        return mockInterceptor.process(request);
    }*/

}
