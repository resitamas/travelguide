package sap.com.travelguide.interactor.detail.event;

import sap.com.travelguide.interactor.ImageEvent;

/**
 * Created by I344065 on 2018. 01. 19..
 */

public class WeatherImageEvent extends ImageEvent {
}
