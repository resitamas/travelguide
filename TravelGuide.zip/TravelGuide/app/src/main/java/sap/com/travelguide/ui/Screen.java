package sap.com.travelguide.ui;

/**
 * Created by I344065 on 2018. 01. 18..
 */

public interface Screen {
    void showMessage(String message);
}
