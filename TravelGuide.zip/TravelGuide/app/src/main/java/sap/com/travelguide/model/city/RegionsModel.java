package sap.com.travelguide.model.city;

import java.util.List;

/**
 * Created by I344065 on 2018. 01. 18..
 */

public class RegionsModel {

    List<RegionModel> regions;

    public List<RegionModel> getRegions() {
        return regions;
    }

    public void setRegions(List<RegionModel> regions) {
        this.regions = regions;
    }
}
