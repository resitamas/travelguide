package sap.com.travelguide.network;

/**
 * Created by I344065 on 2018. 01. 18..
 */

public class CityApi {
}
