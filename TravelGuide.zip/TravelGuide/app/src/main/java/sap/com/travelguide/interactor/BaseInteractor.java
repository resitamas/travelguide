package sap.com.travelguide.interactor;

/**
 * Created by I344065 on 2018. 01. 19..
 */

public abstract class BaseInteractor {


}


