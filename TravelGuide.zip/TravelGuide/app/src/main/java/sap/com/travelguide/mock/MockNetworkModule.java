package sap.com.travelguide.mock;

/**
 * Created by I344065 on 2018. 01. 18..
 */

public class MockNetworkModule {
}
